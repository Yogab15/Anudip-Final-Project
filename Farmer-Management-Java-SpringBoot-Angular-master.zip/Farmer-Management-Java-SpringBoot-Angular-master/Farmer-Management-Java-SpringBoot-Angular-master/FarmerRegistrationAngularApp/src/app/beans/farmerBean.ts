export class FarmerBean {
  id : any;
  name : any;
  fathersName : any;
  age : any;
  gender : any;
  relation : any;
  mobile : any;
  bank : any;
  ifscCode : any;
  accountNumber: any;
  uniqueId: any;
  janAdhaar : any;
  acknowledge : any;
  aadhar : any;
  relationList : any;
}
