export class ResponseBean{
    status : any;
}