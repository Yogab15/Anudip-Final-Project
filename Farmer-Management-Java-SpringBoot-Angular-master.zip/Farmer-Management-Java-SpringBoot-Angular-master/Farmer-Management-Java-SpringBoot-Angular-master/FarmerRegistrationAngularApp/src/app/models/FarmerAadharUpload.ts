import {Farmer} from "./farmer";

export class FarmerAadharUpload{
  farmerAadharId : any;
  farmerName : any;
  aadharDocUploadPath : any;
  farmerId : Farmer = new Farmer();
}
