export class Aadhar{
  id : any;
  aadharId : any;
}
