export class Acknowledge{
  id : any;
  acknowledgeId : any;
}
