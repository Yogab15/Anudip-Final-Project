export class Bank{
  id : any;
  bankName : any;
  ifscCode : any;
  accountNumber : any;
  mobileNumber : any;
}
