export class FarmerImage{
  id : any;
  name : any;
  farmerImagePath : any;
}
