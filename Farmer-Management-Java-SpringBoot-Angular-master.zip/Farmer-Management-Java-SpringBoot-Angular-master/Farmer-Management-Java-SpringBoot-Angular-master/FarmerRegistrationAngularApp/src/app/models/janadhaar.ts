export class Janadhaar{
  id : any;
  janadhaarId : any;
}
