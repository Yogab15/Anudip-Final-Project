# OrganicAura
Organic Aura Where a Farmer Can Register by Self and can see the products and purchase whatever the product they want <br>
Technology used in this Project are Springboot using of Java for Backend Operations and For Database Both Sql Server and MySql are used.<br>
Angular used For the Frontend Development and Varios API Services are used Like RazorPay API, Aadhar API.

