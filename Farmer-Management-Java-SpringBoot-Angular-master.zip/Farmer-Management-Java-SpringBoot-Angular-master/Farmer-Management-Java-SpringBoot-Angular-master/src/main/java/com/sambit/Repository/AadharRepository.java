package com.sambit.Repository;

import com.sambit.Model.Aadhar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AadharRepository extends JpaRepository<Aadhar, Integer> {
}
