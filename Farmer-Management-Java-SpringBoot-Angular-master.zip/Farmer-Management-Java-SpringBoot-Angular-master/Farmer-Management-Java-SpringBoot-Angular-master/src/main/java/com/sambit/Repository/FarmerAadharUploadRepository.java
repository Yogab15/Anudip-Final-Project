package com.sambit.Repository;

import com.sambit.Model.FarmerAadharUpload;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FarmerAadharUploadRepository extends JpaRepository<FarmerAadharUpload, Integer> {
}
