package com.sambit.Repository;

import com.sambit.Model.FarmerImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FarmerImageRepository extends JpaRepository<FarmerImage, Integer> {
}
