package com.sambit.Repository;

import com.sambit.Model.Janadhaar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JanadhaarRepository extends JpaRepository<Janadhaar, Integer> {
}
