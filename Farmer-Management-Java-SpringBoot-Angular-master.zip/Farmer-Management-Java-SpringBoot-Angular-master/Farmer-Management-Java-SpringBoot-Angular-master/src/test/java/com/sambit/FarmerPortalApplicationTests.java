package com.sambit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
